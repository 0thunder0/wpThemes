<?php
class td_social_api {
    private $cache_var_name = 'td_social_api_v3';
    private $do_transient_save = false;
    public $td_cache = array(); //the cache


    function __construct() {
        //read the cache into memory
        $this->td_cache = get_transient($this->cache_var_name);
    }





    public function save_transient($cache_time  = 1) {
        //save the cache (in hours), only if we have a change
        if ($this->do_transient_save) {
            set_transient($this->cache_var_name, $this->td_cache, $cache_time * 60 * 60);
        }
    }


    //caching
    private function get_cache($service_id, $user_id) {
        if (isset($this->td_cache[$service_id . '_' . $user_id])) {
            $this->td_cache[$service_id . '_' . $user_id]['is_cache'] = true;
            return $this->td_cache[$service_id . '_' . $user_id];
        } else {
            return false;
        }
    }

    private function set_cache($service_id, $user_id, $data) {
        $this->do_transient_save = true;
        $this->td_cache[$service_id . '_' . $user_id] = $data;
    }


    //url fatching
    private function get_url($url) {
        $td_request_result = @wp_remote_retrieve_body(@wp_remote_get($url, array('timeout' => 18 , 'sslverify' => false)));
        return $td_request_result;
    }

    private function get_json($url) {
        $td_json = @json_decode($this->get_url($url), true);
        return $td_json;
    }


    //prepare a response array
    private function response_array() {
        return array(
            'time' => time(),
            'count' => 0
        );
    }






    //the services
    public function get_facebook($user_id) {
        $service_id = 'facebook';
        $buffy_array = $this->response_array();
        if ($this->get_cache($service_id, $user_id) === false) {
            try {
                $td_data = @$this->get_json("http://graph.facebook.com/$user_id");
                //if (!isset($td_data['error'])) {
                if (!empty($td_data['likes'])) {
                    $buffy_array['count'] = (int) $td_data['likes'];
                }
            } catch (Exception $e) {
            }
            $this->set_cache($service_id, $user_id, $buffy_array);
            return $buffy_array;
        } else {
           return $this->get_cache($service_id, $user_id);
        }
    }

    public function get_youtube($user_id) {
        $service_id = 'youtube';
        $buffy_array = $this->response_array();

        if ($this->get_cache($service_id, $user_id) === false) {
            try {
                $td_data = @$this->get_json("http://gdata.youtube.com/feeds/api/users/$user_id?alt=json");
                if (!empty($td_data['entry']['yt$statistics']['subscriberCount'])) {
                    $buffy_array['count'] = (int) $td_data['entry']['yt$statistics']['subscriberCount'];
                }
            } catch (Exception $e) {
            }
            $this->set_cache($service_id, $user_id, $buffy_array);
            return $buffy_array;
        } else {
            return $this->get_cache($service_id, $user_id);
        }
    }

    public function get_vimeo($user_id) {
        $service_id = 'youtube';
        $buffy_array = $this->response_array();

        if ($this->get_cache($service_id, $user_id) === false) {
            try {
                $td_data = @$this->get_json("http://vimeo.com/api/v2/channel/$user_id/info.json");
                if (!empty($td_data['total_subscribers'])) {
                    $buffy_array['count'] = (int) $td_data['total_subscribers'];
                }
            } catch (Exception $e) {
            }
            $this->set_cache($service_id, $user_id, $buffy_array);
            return $buffy_array;
        } else {
            return $this->get_cache($service_id, $user_id);
        }
    }


    public function get_twitter($user_id) {
        $service_id = 'twitter';
        $buffy_array = $this->response_array();

        if ($this->get_cache($service_id, $user_id) === false) {
            if (!class_exists('TwitterApiClient')) {
                require_once 'twitter-client.php';
                $Client = new TwitterApiClient;
                $Client->set_oauth (YOUR_CONSUMER_KEY, YOUR_CONSUMER_SECRET, SOME_ACCESS_KEY, SOME_ACCESS_SECRET);
                try {
                    $path = 'users/show';
                    $args = array ('screen_name' => $user_id);
                    $data = @$Client->call( $path, $args, 'GET' );
                    if (!empty($data['followers_count'])) {
                        $buffy_array['count'] = $data['followers_count'];
                    }
                }
                catch( TwitterApiException $Ex ){
                }
                $this->set_cache($service_id, $user_id, $buffy_array);
                return $buffy_array;
            }
        } else {
            return $this->get_cache($service_id, $user_id);
        }
    }


    public function get_google_plus($user_id) {
        $service_id = 'googleplus';
        $buffy_array = $this->response_array();

        if ($this->get_cache($service_id, $user_id) === false) {
            try {
                $td_data = @$this->get_json("https://www.googleapis.com/plus/v1/people/$user_id?key=AIzaSyA1hsdPPNpkS3lvjohwLNkOnhgsJ9YCZWw");
                if (!empty($td_data['plusOneCount'])) {
                    $buffy_array['count'] = (int) $td_data['plusOneCount'];
                }else{
                    $td_data = @$this->get_url("https://plus.google.com/$user_id/posts");
                    $pattern = "/<span role=\"button\" class=\"d-s o5a\" tabindex=\"0\">(.*?)<\/span>/";
                    preg_match($pattern, $td_data, $matches);
                    if (!empty($matches[1])) {
                        $buffy_array['count'] = (int) $matches[1];
                    }
                }
            } catch (Exception $e) {
            }
            $this->set_cache($service_id, $user_id, $buffy_array);
            return $buffy_array;
        } else {
            return $this->get_cache($service_id, $user_id);
        }
    }


    public function get_instagram($user_id) {
        $service_id = 'instagram';
        $buffy_array = $this->response_array();

        if ($this->get_cache($service_id, $user_id) === false) {
            try {
                $td_data = @$this->get_url("http://instagram.com/$user_id#");
                $pattern = "/followed_by\":(.*?),\"follows\":/";
                preg_match($pattern, $td_data, $matches);
                if (!empty($matches[1])) {
                    $buffy_array['count'] = (int) $matches[1];
                }
            } catch (Exception $e) {
            }
            $this->set_cache($service_id, $user_id, $buffy_array);
            return $buffy_array;
        } else {
            return $this->get_cache($service_id, $user_id);
        }
    }


    public function get_soundcloud($user_id) {
        $service_id = 'soundcloud';
        $buffy_array = $this->response_array();

        if ($this->get_cache($service_id, $user_id) === false) {
            try {
                $td_data = @$this->get_json("http://api.soundcloud.com/users/$user_id.json?client_id=97220fb34ad034b5d4b59b967fd1717e");
                if (!empty($td_data['followers_count'])) {
                    $buffy_array['count'] = (int) $td_data['followers_count'];
                }
            } catch (Exception $e) {
            }
            $this->set_cache($service_id, $user_id, $buffy_array);
            return $buffy_array;
        } else {
            return $this->get_cache($service_id, $user_id);
        }
    }

    //for now the user write is own number of folowers
    public function get_rss($user_id) {
        $service_id = 'rss';
        $buffy_array = $this->response_array();
        /*
        if ($this->get_cache($service_id, $user_id) === false) {
            try {
                $td_data = @$this->get_json("http://api.soundcloud.com/users/$user_id.json?client_id=97220fb34ad034b5d4b59b967fd1717e");
                $buffy_array['count'] = (int) $td_data['followers_count'];
            } catch (Exception $e) {
            }
            $this->set_cache($service_id, $user_id, $buffy_array);
            return $buffy_array;
        } else {
            return $this->get_cache($service_id, $user_id);
        }*/

        $buffy_array['count'] = (int) $user_id;
        return $buffy_array;
    }


}